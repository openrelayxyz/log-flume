import gzip
import base64
import json
import re
import boto3
import datetime
import os

client = boto3.client('cloudwatch')

FLUME_BLOCK_NUM_RE = re.compile(r"Committing \d+ logs up to block (\d+)")
LOG_COUNT_RE = re.compile(r"Committing (\d+) logs up to block \d+")
BLOCK_STATS_RE = re.compile(r"SQLite Pool - Open: .* Head Block: (\d+)")

# Committed Block 12252504 (0x23aa26ba58aa7360c62f6b5f3b25f9f94423971ee4a7122bf5d021409c6f0f9e) in 410.916819ms (age 13.33298528s)

# 6h55m49.105414477s

BLOCK_NUM_RE = re.compile(r"Committed Block (\d+)")
PROCESS_TIME_RE = re.compile(r"Committed Block \d+ \(0x[0-9a-f]{64}\) in (?:(\d+)h)?(?:(\d+)m)?(?:(\d+.\d+)s)?(?:(\d+.\d+)ms)?")
BLOCK_AGE_RE = re.compile(r"Committed Block \d+ \(0x[0-9a-f]{64}\) in [^\s]+ \(age (?:(\d+)h)?(?:(\d+)m)?(?:(\d+.\d+)s)?(?:(\d+.\d+)ms)?\)")



def numberFromRe(message, regex):
    m = regex.search(message)
    if not m:
        raise ValueError("Message does not match regex")
    return int(m.groups()[0])

def durationFromRe(message, regex):
    m = regex.search(message)
    if not m:
        raise ValueError("Message does not match regex")
    h, m, s, ms = m.groups()
    total = 0
    if h:
        total += int(h) * 3600000
    if m:
        total += int(m) * 60000
    if s:
        total += int(float(s) * 1000)
    if ms:
        total += int(float(ms))
    return total



def appendMetric(item, metricData, metricName, value, unit="None", stream=None):
    dimensions = [
        {
            'Name': 'clusterId',
            'Value': os.environ.get("CLUSTER_ID")
        },
    ]
    if stream:
        dimensions.append({
            'Name': 'instanceId',
            'Value': stream
        })
    metricData.append({
        'MetricName': metricName,
        'Dimensions': dimensions,
        'Timestamp': datetime.datetime.utcfromtimestamp(
            item["timestamp"] / 1000
        ),
        'Value': value,
        'Unit': unit,
    })


def flumeHandler(event, context):
    eventData = json.loads(gzip.decompress(base64.b64decode(
        event["awslogs"]["data"])
    ))
    for item in eventData["logEvents"]:
        metricData = []
        try:
            if "Committed Block" in item["message"]:
                appendMetric(item, metricData, "block",
                             numberFromRe(item["message"], BLOCK_NUM_RE))
                appendMetric(item, metricData, "processing_time",
                             durationFromRe(item["message"], PROCESS_TIME_RE))
                appendMetric(item, metricData, "age",
                             durationFromRe(item["message"], BLOCK_AGE_RE))
        except ValueError:
            pass
        try:
            if "SQLite Pool" in eventData["logEvents"]:
                appendMetric(item, metricData, "block",
                             numberFromRe(item["message"], BLOCK_STATS_RE))
        except ValueError:
            pass
        if len(metricData) >= 20:
            client.put_metric_data(
                Namespace='FlumeData',
                MetricData=metricData[:20],
            )
            metricData = metricData[20:]
    if metricData:
        client.put_metric_data(
            Namespace='FlumeData',
            MetricData=metricData,
        )
