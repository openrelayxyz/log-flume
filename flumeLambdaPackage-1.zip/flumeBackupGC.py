import boto3
import os

s3 = boto3.client('s3')
sns = boto3.client('sns')


def gcHandler(event, context):
    topics = os.environ.get("SNS_TOPICS").split(";")
    bucketName = os.environ.get("BACKUP_BUCKET")
    network = os.environ.get("NETWORK_ID")
    currentSnapshot = os.environ.get("CURRENT_SNAPSHOT").strip("/")
    response = s3.list_objects(
        Bucket=bucketName,
        Prefix="%s/flume-",
        Delimiter="/"
    )
    prefixes = sorted(prefix["Prefix"].strip("/") for prefix in response["CommonPrefixes"])
    if currentSnapshot.startswith(bucketName):
        currentPrefix = currentSnapshot[len(bucketName):]
        if currentPrefix not in prefixes:
            for topic in topics:
                sns.publish(
                    TopicArn=topic,
                    Subject="Warning: Flume %s snapshot unavailable" % network,
                    Message="The current flume snapshot for %s is %s, but could not be found." % (network, currentSnapshot),
                )
    threshold = datetime.datetime.utcnow() - datetime.timedelta(hours=25)
    latestSnap = "%s/flume-%s" % (network, threshold.strftime("%Y%m%d-%H%M%S"))
    if prefixes[-1] < threshold:
        for topic in topics:
            sns.publish(
                TopicArn=topic,
                Subject="Warning: Flume %s snapshot outdated" % network,
                Message="The current flume snapshot for %s is exists, but is outdated" % (network),
            )
    # Delete all but the 5 most recent snapshots
    for prefix in prefixes[:-5]:
        response = s3.list_objects(
            Bucket=bucketName,
            Prefix=prefix + "/",
        )
        while response.get("Contents"):
            s3.delete_objects(
                Bucket=bucketName,
                Delete={
                    'Objects': [{"Key": item["Key"]} for item in response["Contents"]],
                    'Quiet': True,
                }
            )
            response = s3.list_objects(
                Bucket=bucketName,
                Prefix=prefix + "/",
            )
